# Motion-detection-using-python
A motion detection system using python
